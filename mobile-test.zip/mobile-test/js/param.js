define([],function(){
	var api = 'http://zhenzhen.s1.natapp.cc/zzht/';
	//var api = 'http://192.168.199.127/zzht/';
	//var api = 'http://service.myzhenzhen.com/zzht/';
	var imgLink = 'http://o6uda1nl0.bkt.clouddn.com/';//内网
	//var imgLink = 'http://7xrr05.com1.z0.glb.clouddn.com/';//外网
})